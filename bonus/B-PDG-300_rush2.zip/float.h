/*
** EPITECH PROJECT, 2025
** Paradigms Seminar
** File description:
** Exercice 04
*/

#pragma once

#include "object.h"

extern const Class  *Float;
